import time
def test_dependency_smoke():
    time.sleep(3)
