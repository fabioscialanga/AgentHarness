def test_dependency_smoke():
    assert True
