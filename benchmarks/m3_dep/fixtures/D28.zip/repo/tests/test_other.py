def test_unrelated():
    assert True

# changed after check
