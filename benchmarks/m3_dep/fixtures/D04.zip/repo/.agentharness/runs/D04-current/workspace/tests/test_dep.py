def test_dependency_smoke():
    assert False, 'synthetic failure'
