from pathlib import Path
import tempfile
def test_dependency_smoke():
    assert (Path(tempfile.gettempdir()) / 'agentharness-m3-d29-control.txt').read_text().strip() == 'pass'
